/*
  I use this Interceptor to apply the Authorization token to all http request
*/

import { Injectable } from '@angular/core';
import {HttpEvent, HttpInterceptor, HttpHandler, HttpRequest} from '@angular/common/http';
import {Observable} from "rxjs";

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
	private token = "4da0506e7acbbf2a002e7f46a109308eb1625f56"; // I copied this token from the backend url : http://localhost:8000/admin/authtoken/token/
  constructor(){

  }
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    req = req.clone({
      /*setHeaders: {
        Authorization: `Token ${this.token}`
      }*/ 
      headers: req.headers.set('Authorization', `Token ${this.token}`)
      });

    return next.handle(req);
  }
}

