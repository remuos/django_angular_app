export class Cart {
	id: number;
	userId: number;
    item_id: number ;
    date_creation: string;
}