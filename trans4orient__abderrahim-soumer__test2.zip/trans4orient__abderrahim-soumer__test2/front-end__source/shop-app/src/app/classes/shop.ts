import {Cart} from './cart';

export class Shop {
	id : number ;
	titre : string ;
	description : string ;
	img_url : string ;
	pub_date : string ;
	carts: Cart[];
}