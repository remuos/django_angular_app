import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable, of } from 'rxjs';

import { Shop } from './classes/shop';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization': 'my-auth-token'
  })
  };

@Injectable({
  providedIn: 'root'
})
export class ShopsService {
  /*
    I declare the endpoint here because this is the only service i have but that is not recommanded 
  */
	private host ='http://localhost:8000';
  private allShops = '/shops/items/';
	private cart_endpoint = '/shops/carts/';
  private userActiveId = 1 ; // I assume that the user id is 1 

  constructor(private http: HttpClient) { }

  /** GET heroes from the server */
getShops (): Observable<Shop[]> {
  return this.http.get<Shop[]>(this.host+''+this.allShops)
}
getPreferredShops (): Observable<Shop[]> {
  return this.http.get<Shop[]>(this.host+''+this.allShops+`?userId=${this.userActiveId}`)
}

getNotPreferredShops (): Observable<Shop[]> {
  return this.http.get<Shop[]>(this.host+''+this.allShops+`?not_userId=${this.userActiveId}`)
}

addCart(itemId) : Observable<Shop[]> {
    return this.http.post<Shop[]>(this.host+''+this.cart_endpoint, {
      userId: this.userActiveId,
      item_id: itemId ,
      date_creation: new Date(),
    });
  }

deleteCart(cartId) : Observable<Shop[]> {
    return this.http.delete<Shop[]>(this.host+''+this.cart_endpoint+`${cartId}/`);
  }

}
