import { Component, OnInit ,Input} from '@angular/core';

import { Shop } from '../classes/shop';
import { ShopsService } from '../shops.service';

@Component({
  selector: 'app-listing',
  templateUrl: './listing.component.html',
  styleUrls: ['./listing.component.css']
})

export class ListingComponent implements OnInit {
  @Input()  shops: Shop[] = [];
  @Input()  prefered: boolean = false ;

  constructor(private shopsService: ShopsService) { }

  ngOnInit() {
  	
  }

  addCart(shop): void{
	this.shopsService.addCart(shop.id).subscribe(
        res => {
          let index = this.shops.indexOf(shop);
          if(index >= 0){
          	this.shops.splice(index, 1);
          }
          console.log(index,this.shops);
        },
        err => {
          console.log("Error occured");
        }
      );
}
 
removeCart(shop): void{
	let cartId = this.findCartId(shop);
	if(cartId < 0){
		return ;
	}
	this.shopsService.deleteCart(cartId).subscribe(
        res => {
          let index = this.shops.indexOf(shop);
          if(index >= 0){
          	this.shops.splice(index, 1);
          }
          console.log(index,this.shops);
        },
        err => {
          console.log("Error occured");
        }
      );
}

findCartId(shop): number{
	for(let i=0 ; i < shop.carts.length; i++){
		if(shop.carts[i].userId = 1){
			return shop.carts[i].id ;
		}
	}
	return -1 ;
}
}
