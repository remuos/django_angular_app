import { Component, OnInit } from '@angular/core';

import { ShopsService } from '../shops.service';
import { Shop } from '../classes/shop';

@Component({
  selector: 'app-preferred',
  templateUrl: './preferred.component.html',
  styleUrls: ['./preferred.component.css']
})
export class PreferredComponent implements OnInit {

  preferredShop: Shop[] = [];
  constructor(private shopsService: ShopsService) { }

  ngOnInit() {
  	this.getPreferredShops();
  }
  getPreferredShops(): void {
    this.shopsService.getPreferredShops()
        .subscribe(shops => this.preferredShop = shops);
  }
}
