import { Component, OnInit } from '@angular/core';

import { ShopsService } from '../shops.service';
import { Shop } from '../classes/shop';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  notPreferredShop: Shop[] = [];
  constructor(private shopsService: ShopsService) { }

  ngOnInit() {
  	this.getNotPreferredShops();
  	
  }
  getNotPreferredShops(): void {
    this.shopsService.getNotPreferredShops()
        .subscribe(shops => this.notPreferredShop = shops);
  }


}
